﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test
{
    public class Prenos
    {
        public int godina;
        public int tezina;
        public string ime;
        public Prenos()
        {
        }
    }
}
